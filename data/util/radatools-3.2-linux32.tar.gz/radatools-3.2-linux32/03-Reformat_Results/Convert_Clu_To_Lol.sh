
# See README.txt for details
echo -----------
./Convert_Clu_To_Lol.exe
./Convert_Clu_To_Lol.exe  test-3+1+3.clu  test-3+1+3-clu-lol1.txt
./Convert_Clu_To_Lol.exe  test-3+1+3.clu  test-3+1+3-clu-lol2.txt  sorted
echo -----------
