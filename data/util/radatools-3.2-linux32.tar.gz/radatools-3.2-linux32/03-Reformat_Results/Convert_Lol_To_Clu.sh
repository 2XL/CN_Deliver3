
# See README.txt for details
echo -----------
./Convert_Lol_To_Clu.exe
./Convert_Lol_To_Clu.exe  test-3+1+3-lol1.txt  test-3+1+3-lol1.clu  4
./Convert_Lol_To_Clu.exe  test-3+1+3-lol2.txt  test-3+1+3-lol2.clu  4
./Convert_Lol_To_Clu.exe  test-3+1+3-lol3.txt  test-3+1+3-lol3.clu  4
./Convert_Lol_To_Clu.exe  test-real-lol.txt    test-real.clu        4
echo -----------
