
# See README.txt for details
echo -----------
./Reformat_Partitions.exe
./Reformat_Partitions.exe test-real.net test-real-lol.txt test-real-lol-reformat1.txt 4 CH
./Reformat_Partitions.exe test-real.net test-real.clu     test-real-lol-reformat2.txt 4 NH 5 13 0
./Reformat_Partitions.exe test-real.net test-real-lol.txt test-real-lol-reformat3.txt 4 SH 5 13 25
./Reformat_Partitions.exe test-3+1+3.net test-3+1+3-lols-improved.txt test-3+1+3-lols-improved-reformat.txt 4 CH 10 4 0
echo -----------
