
# See README.txt for details
echo -----------
./Size_Reduction_Lol_Expand.exe
./Size_Reduction_Lol_Expand.exe test-size-reduced-lol.txt test-size-reducer.txt test-size-expanded-lol.txt 4 CH
echo -----------
