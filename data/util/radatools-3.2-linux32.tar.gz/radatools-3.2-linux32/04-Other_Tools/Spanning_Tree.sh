
# See README.txt for details
echo -----------
./Spanning_Tree.exe
./Spanning_Tree.exe  test-spanning_tree.net  test-spanning_tree-min.net  MIN  Integer
./Spanning_Tree.exe  test-spanning_tree.net  test-spanning_tree-max.net  MAX  Float  2
echo -----------
