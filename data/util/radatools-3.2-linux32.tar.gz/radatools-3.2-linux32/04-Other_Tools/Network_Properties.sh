
# See README.txt for details
echo -----------
./Network_Properties.exe
./Network_Properties.exe  test-props01.net  NEUF  4
./Network_Properties.exe  test-props01.net  GELU  4
./Network_Properties.exe  test-props01.net  all
./Network_Properties.exe  test-props02.net  6
./Network_Properties.exe  test-props03.net
echo -----------
