
# See README.txt for details
echo -----------
./Compare_Partitions.exe
./Compare_Partitions.exe  test-3+1+3-lol1.txt  test-3+1+3-lol1.clu  4
./Compare_Partitions.exe  test-3+1+3-lol1.txt  test-3+1+3-lol2.txt  test-3+1+3-compare_lol1_lol2.txt  4
./Compare_Partitions.exe  test-3+1+3-lol1.clu  test-3+1+3-lol3.clu
echo -----------

