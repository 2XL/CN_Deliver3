
# See README.txt for details
echo -----------
./Modularity_Calculation.exe
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol1.clu WN
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.txt WN T   4
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.txt WN TCN 4
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.txt WN TC  4
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.txt WN TN  4
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.clu  0.5 UN T
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.clu  1.0 WN T
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.clu  1.0 WS T
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.clu  0.0 WS T
./Modularity_Calculation.exe test-3+1+3.net test-3+1+3-lol3.clu -1.0 WS T
echo -----------
