
# See README.txt for details
echo -----------
./Net_To_Matrix.exe
./Net_To_Matrix.exe test-3+1+3.net  test-3+1+3.txt  0
./Net_To_Matrix.exe test-signed.net test-signed.txt .
./Net_To_Matrix.exe test-size.net   test-size.txt   0.0
echo -----------
