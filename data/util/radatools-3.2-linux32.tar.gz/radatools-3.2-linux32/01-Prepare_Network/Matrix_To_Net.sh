
# See README.txt for details
echo -----------
./Matrix_To_Net.exe
./Matrix_To_Net.exe test-matrix01.txt test-matrix01.net
./Matrix_To_Net.exe test-matrix02.txt test-matrix02.net N/A
./Matrix_To_Net.exe test-matrix03.txt test-matrix03.net 0
echo -----------
