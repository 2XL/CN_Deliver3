
# See README.txt for details
echo -----------
./Extract_Subgraphs.exe
./Extract_Subgraphs.exe test-3+1+3.net test-3+1+3.clu      test-3+1+3
./Extract_Subgraphs.exe test-real.net  test-real-list1.txt test-real-list1  4
./Extract_Subgraphs.exe test-real.net  test-real-list2.txt test-real-list2
echo -----------
