
# See README.txt for details
echo -----------
./Connected_Subgraphs.exe
./Connected_Subgraphs.exe test-list01 strong
./Connected_Subgraphs.exe test-list02 weak
./Connected_Subgraphs.exe test-real
echo -----------
