
# See README.txt for details
echo -----------
./List_To_Net.exe
./List_To_Net.exe test-list01.txt test-list01.net
./List_To_Net.exe test-list02.txt test-list02.net undirected
./List_To_Net.exe test-real.txt   test-real.net
echo -----------
