
# See README.txt for details
echo -----------
./Size_Reduction.exe
./Size_Reduction.exe test-size Float 2
./Size_Reduction.exe test-size Integer
./Size_Reduction.exe test-size-reduced Double 6
echo -----------
