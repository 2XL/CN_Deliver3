
# See README.txt for details
echo -----------
./Mesoscales_Fine_Tuning.exe
./Mesoscales_Fine_Tuning.exe test-3+1+3 WS
echo -----------
