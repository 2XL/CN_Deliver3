
# See README.txt for details
echo -----------

# Usage information
./Communities_Detection.exe

# Exhaustive (h) search to optimize modularity (only for very small networks)
./Communities_Detection.exe p WN h      1       test-3+1+3.net test-3+1+3-lol1.txt

# Extremal (e) optimization with fine-tuning (rfr), 10 repetitions
./Communities_Detection.exe v WN erfr  10       test-3+1+3.net test-3+1+3-lol2.txt

# Tabu (t) search with fine-tuning (rfr) and a self-loop of 0.5 added to all nodes
./Communities_Detection.exe v WN trfr   5  0.5  test-3+1+3.net test-3+1+3-lol3.txt

# Signed (WS) network
./Communities_Detection.exe s WS h  1  test-signed.net test-signed-lol1.txt
#    and wrong partition
./Communities_Detection.exe s WN h  1  test-signed.net test-signed-lol2.txt


# Real network
#    First, Spectral (s), Extremal (e) and fine-tuning (rfr)
./Communities_Detection.exe v WN serfr  3  test-real.net  test-real-lol.txt
#    Then, additional optimization with Tabu (t) search and fine-tuning (rfr)
./Communities_Detection.exe v WN trfr   3  test-real.net  test-real-lol.txt

echo -----------
