
# See README.txt for details
echo -----------

# Usage information
./Mesoscales_Search.exe

# Tabu (t) search with fine-tuning (rfr), 10 repetitions, 100 uniform intervals of the self-loop
./Mesoscales_Search.exe test-3+1+3.net WS trfr 10 100 1.0

echo -----------
